import os
import sys
import subprocess
import pygame
import json
import requests
import shutil
import ctypes

class Console:
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)
        pygame.display.set_caption("My Game Console")
        self.clock = pygame.time.Clock()
        self.load_firmware()
        self.running = True
        self.in_settings = False
        self.in_shop = False
        self.in_games = False
        self.cd_drive_path = "/media/cdrom"

        self.init_controllers()

    def load_firmware(self):
        lib_path = os.path.join('system', 'system_firm.so')  # .dll for Windows
        if os.path.exists(lib_path):
            self.firmware = ctypes.CDLL(lib_path)
            self.firmware.load()
        else:
            self.show_error_message("Firmware file not found!")

    def show_menu(self):
        menu_image = pygame.image.load('system/menu.jpeg')
        disk_image = pygame.image.load('system/disk.jpeg')
        config_image = pygame.image.load('system/config.jpeg')
        poweroff_image = pygame.image.load('system/poweroff.jpeg')
        shop_image = pygame.image.load('system/shop.jpeg')
        games_image = pygame.image.load('system/games.jpeg')

        menu_image = pygame.transform.scale(menu_image, (self.screen.get_width(), self.screen.get_height()))
        icon_width, icon_height = 100, 100
        disk_image = pygame.transform.scale(disk_image, (icon_width, icon_height))
        config_image = pygame.transform.scale(config_image, (icon_width, icon_height))
        poweroff_image = pygame.transform.scale(poweroff_image, (icon_width, icon_height))
        shop_image = pygame.transform.scale(shop_image, (icon_width, icon_height))
        games_image = pygame.transform.scale(games_image, (icon_width, icon_height))

        center_x = self.screen.get_width() // 2
        center_y = self.screen.get_height() // 2
        spacing = 50
        total_width = 5 * icon_width + 4 * spacing

        disk_pos = (center_x - total_width // 2, center_y - icon_height // 2)
        config_pos = (disk_pos[0] + icon_width + spacing, center_y - icon_height // 2)
        poweroff_pos = (config_pos[0] + icon_width + spacing, center_y - icon_height // 2)
        shop_pos = (poweroff_pos[0] + icon_width + spacing, center_y - icon_height // 2)
        games_pos = (shop_pos[0] + icon_width + spacing, center_y - icon_height // 2)

        self.disk_rect = pygame.Rect(disk_pos, (icon_width, icon_height))
        self.config_rect = pygame.Rect(config_pos, (icon_width, icon_height))
        self.poweroff_rect = pygame.Rect(poweroff_pos, (icon_width, icon_height))
        self.shop_rect = pygame.Rect(shop_pos, (icon_width, icon_height))
        self.games_rect = pygame.Rect(games_pos, (icon_width, icon_height))

        self.screen.blit(menu_image, (0, 0))
        self.screen.blit(disk_image, disk_pos)
        self.screen.blit(config_image, config_pos)
        self.screen.blit(poweroff_image, poweroff_pos)
        self.screen.blit(shop_image, shop_pos)
        self.screen.blit(games_image, games_pos)
        pygame.display.flip()

    def show_animation(self):
        for alpha in range(0, 256, 5):
            self.screen.fill((0, 0, 0))
            s = pygame.Surface(self.screen.get_size())
            s.set_alpha(alpha)
            s.fill((255, 255, 255))
            self.screen.blit(s, (0, 0))
            pygame.display.flip()
            self.clock.tick(60)

    def show_system_settings(self):
        sys_ver_path = os.path.join('data', 'sys.ver')
        if os.path.exists(sys_ver_path):
            with open(sys_ver_path, 'r') as file:
                system_version = file.read().strip()
        else:
            system_version = "Unknown"

        running = True
        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        running = False

            self.screen.fill((0, 0, 0))
            font = pygame.font.Font(None, 36)
            text = font.render(f"System Version: {system_version}", True, (255, 255, 255))
            self.screen.blit(text, (100, 100))

            settings_text = font.render("Press ESC to return to menu", True, (255, 255, 255))
            self.screen.blit(settings_text, (100, 150))

            bluetooth_text = font.render("Bluetooth Settings: (not using Ubuntu settings)", True, (255, 255, 255))
            self.screen.blit(bluetooth_text, (100, 200))

            pygame.display.flip()
            self.clock.tick(60)

    def show_shop(self):
        url = 'https://webwarpgames.github.io/shop/games.json'
        try:
            response = requests.get(url)
            games = response.json()
        except Exception as e:
            self.show_error_message(f"Error fetching shop data: {e}")
            games = []

        running = True
        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        running = False
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    for game in games:
                        game_rect = pygame.Rect(100, 150 + 50 * games.index(game), 600, 40)
                        if game_rect.collidepoint(event.pos):
                            self.download_and_install_game(game['url'], game['name'])

            self.screen.fill((0, 0, 0))
            font = pygame.font.Font(None, 36)
            text = font.render("Shop - Select a game to download", True, (255, 255, 255))
            self.screen.blit(text, (100, 100))

            y = 150
            for game in games:
                game_text = font.render(f"{game['name']} - {game['description']}", True, (255, 255, 255))
                self.screen.blit(game_text, (100, y))
                y += 50

            pygame.display.flip()
            self.clock.tick(60)

    def download_and_install_game(self, url, game_name):
        try:
            response = requests.get(url, stream=True)
            game_path = os.path.join('games', f"{game_name}.py")
            with open(game_path, 'wb') as file:
                shutil.copyfileobj(response.raw, file)
            self.show_message(f"Game {game_name} installed successfully.")
        except Exception as e:
            self.show_error_message(f"Failed to download {game_name}: {e}")

    def show_games(self):
        games_dir = os.path.join('games')
        if not os.path.exists(games_dir):
            os.makedirs(games_dir)

        games = [f for f in os.listdir(games_dir) if f.endswith('.py')]

        running = True
        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        running = False
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    for game in games:
                        game_rect = pygame.Rect(100, 150 + 50 * games.index(game), 600, 40)
                        if game_rect.collidepoint(event.pos):
                            self.run_game(game)

            self.screen.fill((0, 0, 0))
            font = pygame.font.Font(None, 36)
            text = font.render("Games - Select a game to play", True, (255, 255, 255))
            self.screen.blit(text, (100, 100))

            y = 150
            for game in games:
                game_text = font.render(game, True, (255, 255, 255))
                self.screen.blit(game_text, (100, y))
                y += 50

            pygame.display.flip()
            self.clock.tick(60)

    def run_game(self, game):
        game_path = os.path.join('games', game)
        if os.path.exists(game_path):
            subprocess.run(['python3', game_path])
        else:
            self.show_error_message(f"Game {game} not found.")

    def run(self):
        while self.running:
            self.show_menu()
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    if self.disk_rect.collidepoint(event.pos):
                        self.run_disk_application()
                    elif self.config_rect.collidepoint(event.pos):
                        self.show_animation()
                        self.show_system_settings()
                    elif self.poweroff_rect.collidepoint(event.pos):
                        pygame.quit()
                        sys.exit()
                    elif self.shop_rect.collidepoint(event.pos):
                        self.show_shop()
                    elif self.games_rect.collidepoint(event.pos):
                        self.show_games()
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        self.running = False

                elif event.type == pygame.JOYBUTTONDOWN:
                    self.handle_controller_input(event)

            pygame.display.flip()
            self.clock.tick(60)

    def run_disk_application(self):
        disk_path = os.path.join(self.cd_drive_path, 'main.py')
        if os.path.exists(disk_path):
            subprocess.run(['python3', disk_path])
        else:
            self.show_error_message("main.py not found in CD drive.")

    def init_controllers(self):
        pygame.joystick.init()
        self.controllers = []
        for i in range(pygame.joystick.get_count()):
            joystick = pygame.joystick.Joystick(i)
            joystick.init()
            self.controllers.append(joystick)

    def handle_controller_input(self, event):
        if event.type == pygame.JOYBUTTONDOWN:
            if event.button == 0:  # Beispiel: Button 0 für Auswahl
                print("Button 0 pressed")
            elif event.button == 1:  # Beispiel: Button 1 für Zurück
                print("Button 1 pressed")

    def show_message(self, message):
        running = True
        while running:
            for event in pygame.event.get():
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_RETURN:
                        running = False

            self.screen.fill((0, 0, 0))
            font = pygame.font.Font(None, 36)
            text = font.render(message, True, (255, 255, 255))
            self.screen.blit(text, (100, 100))

            instruction_text = font.render("Press Enter to continue", True, (255, 255, 255))
            self.screen.blit(instruction_text, (100, 150))

            pygame.display.flip()
            self.clock.tick(60)

    def show_error_message(self, error_message):
        self.show_message(f"Error: {error_message}")

if __name__ == "__main__":
    console = Console()
    console.run()
