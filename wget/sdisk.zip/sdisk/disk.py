import os
import subprocess
import pygame

def show_menu(screen):
    # Hier die Logik einfügen, um das Menü anzuzeigen

def run_disk_application(screen):
    # Speichern Sie das aktuelle Arbeitsverzeichnis
    current_dir = os.getcwd()

    try:
        # Wechseln Sie zum Verzeichnis der Disk-Anwendung
        disk_dir = os.path.join(os.path.dirname(__file__), 'disk')
        os.chdir(disk_dir)

        # Starten Sie die Disk-Anwendung (main.py) im aktuellen Verzeichnis
        subprocess.run(['python3', 'main.py'])
        
        # Nachdem main.py beendet ist (durch Drücken von ESC), zeigen Sie das Menü wieder an
        show_menu(screen)
    finally:
        # Stellen Sie das ursprüngliche Arbeitsverzeichnis wieder her
        os.chdir(current_dir)

def main():
    pygame.init()
    screen = pygame.display.set_mode((800, 600))
    pygame.display.set_caption("My Game Console")

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                show_menu(screen)
            elif event.type == pygame.MOUSEBUTTONDOWN:
                # Behandeln Sie Mausklick-Ereignisse hier

        # Führen Sie die Disk-Anwendung aus, wenn ein bestimmtes Ereignis auftritt
        # Hier können Sie Bedingungen hinzufügen, um die Disk-Anwendung zu starten

    pygame.quit()

if __name__ == "__main__":
    main()

